package com.example.zomboid.client;

import com.example.zomboid.ZomboidMod;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ZomboidMod.MODID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientKeybinds {
    public static KeyBinding TOGGLE_CAMERA;

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            TOGGLE_CAMERA = new KeyBinding("key.zomboid.toggle_camera",
                    KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_C, "key.categories.zomboid");
            ClientRegistry.registerKeyBinding(TOGGLE_CAMERA);
        });
    }

    private ClientKeybinds() {}
}
