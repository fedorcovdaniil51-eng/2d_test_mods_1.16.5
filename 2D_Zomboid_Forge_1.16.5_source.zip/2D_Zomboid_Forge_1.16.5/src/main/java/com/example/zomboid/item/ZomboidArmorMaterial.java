package com.example.zomboid.item;

import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.Ingredient;
import net.minecraft.item.Items;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;

public enum ZomboidArmorMaterial implements IArmorMaterial {
    FIELD_GEAR("field_gear", 11, new int[]{2, 4, 3, 1}, 12,
            SoundEvents.ITEM_ARMOR_EQUIP_LEATHER, 0.0F, 0.0F,
            () -> Ingredient.fromItems(Items.LEATHER));

    private static final int[] HEALTH_PER_SLOT = new int[]{13, 15, 16, 11};

    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final java.util.function.Supplier<Ingredient> repairMaterial;

    ZomboidArmorMaterial(String name, int durabilityMultiplier, int[] defense,
                         int enchantability, SoundEvent equipSound, float toughness,
                         float knockbackResistance,
                         java.util.function.Supplier<Ingredient> repairMaterial) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairMaterial = repairMaterial;
    }

    @Override
    public int getDurability(EquipmentSlotType slotIn) {
        return HEALTH_PER_SLOT[slotIn.getIndex()] * durabilityMultiplier;
    }

    @Override
    public int getDamageReductionAmount(EquipmentSlotType slotIn) {
        return defense[slotIn.getIndex()];
    }

    @Override
    public int getEnchantability() {
        return enchantability;
    }

    @Override
    public SoundEvent getSoundEvent() {
        return equipSound;
    }

    @Override
    public Ingredient getRepairMaterial() {
        return repairMaterial.get();
    }

    @Override
    public String getName() {
        return "leather";
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
