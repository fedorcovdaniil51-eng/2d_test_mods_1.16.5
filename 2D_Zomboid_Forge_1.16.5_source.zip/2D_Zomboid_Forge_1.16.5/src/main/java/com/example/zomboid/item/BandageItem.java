package com.example.zomboid.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ActionResult;
import net.minecraft.item.ActionResultType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class BandageItem extends Item {
    public BandageItem(Properties properties) {
        super(properties);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (player.getHealth() >= player.getMaxHealth()) {
            return new ActionResult<>(ActionResultType.PASS, stack);
        }

        if (!world.isRemote) {
            player.heal(4.0F);
            player.getCooldownTracker().setCooldown(this, 60);
            if (!player.isCreative()) {
                stack.shrink(1);
            }
        }
        return new ActionResult<>(ActionResultType.SUCCESS, stack);
    }
}
