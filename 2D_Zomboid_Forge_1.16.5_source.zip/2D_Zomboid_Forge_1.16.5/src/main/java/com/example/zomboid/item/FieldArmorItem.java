package com.example.zomboid.item;

import net.minecraft.entity.Entity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public class FieldArmorItem extends ArmorItem {
    public FieldArmorItem(IArmorMaterial material, EquipmentSlotType slot, Properties properties) {
        super(material, slot, properties);
    }

    // Reuse vanilla leather armor textures so no missing custom texture files are required.
    @Override
    public ResourceLocation getArmorTexture(ItemStack stack, Entity entity,
                                             EquipmentSlotType slot, String type) {
        int layer = slot == EquipmentSlotType.LEGS ? 2 : 1;
        String suffix = type == null ? "" : "_" + type;
        return new ResourceLocation("minecraft",
                "textures/models/armor/leather_layer_" + layer + suffix + ".png");
    }
}
