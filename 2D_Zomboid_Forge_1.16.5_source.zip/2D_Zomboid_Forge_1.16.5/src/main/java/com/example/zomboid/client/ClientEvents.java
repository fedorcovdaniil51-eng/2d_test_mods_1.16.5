package com.example.zomboid.client;

import com.example.zomboid.ZomboidMod;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ZomboidMod.MODID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientEvents {
    private static boolean survivalCamera = false;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ClientKeybinds.TOGGLE_CAMERA == null) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        while (ClientKeybinds.TOGGLE_CAMERA.isPressed()) {
            survivalCamera = !survivalCamera;
            if (mc.player != null) {
                mc.gameSettings.thirdPersonView = survivalCamera ? 1 : 0;
                mc.player.sendMessage(new StringTextComponent(
                        survivalCamera
                                ? "2D Zomboid: survival camera ON (C to switch)"
                                : "2D Zomboid: normal camera"),
                        mc.player.getUniqueID());
            }
        }
    }

    @SubscribeEvent
    public static void adjustCamera(EntityViewRenderEvent.CameraSetup event) {
        if (!survivalCamera) {
            return;
        }
        // A mild overhead angle, while mouse movement still controls normal game look.
        // It is intentionally not a locked camera: Minecraft's crosshair/raycast stays usable.
        float pitch = event.getPitch() + 14.0F;
        event.setPitch(Math.max(-75.0F, Math.min(75.0F, pitch)));
        event.setRoll(0.0F);
    }

    @SubscribeEvent
    public static void drawSurvivalHud(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.fontRenderer == null) {
            return;
        }

        MatrixStack matrix = event.getMatrixStack();
        int x = 8;
        int y = 8;
        AbstractGui.fill(matrix, x - 4, y - 4, x + 162, y + 61, 0xB9000000);
        mc.fontRenderer.drawString(matrix, "2D ZOMBOID", x, y, 0xFFFFB65A);
        mc.fontRenderer.drawString(matrix,
                "HP " + Math.round(mc.player.getHealth()) + "/" +
                        Math.round(mc.player.getMaxHealth()),
                x, y + 13, 0xFFFF6666);
        mc.fontRenderer.drawString(matrix,
                "HUNGER " + mc.player.getFoodStats().getFoodLevel() + "/20",
                x, y + 26, 0xFFFFD166);
        mc.fontRenderer.drawString(matrix,
                "ARMOR " + mc.player.getTotalArmorValue(),
                x, y + 39, 0xFFBBD7FF);
        mc.fontRenderer.drawString(matrix,
                "CAMERA " + (survivalCamera ? "SURVIVAL [C]" : "NORMAL [C]"),
                x, y + 50, 0xFFE4E4E4);
    }

    private ClientEvents() {}
}
