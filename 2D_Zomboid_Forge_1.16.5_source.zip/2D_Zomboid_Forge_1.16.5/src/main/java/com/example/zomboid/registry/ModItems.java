package com.example.zomboid.registry;

import com.example.zomboid.ZomboidMod;
import com.example.zomboid.item.BandageItem;
import com.example.zomboid.item.FieldArmorItem;
import com.example.zomboid.item.ZomboidArmorMaterial;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Food;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ZomboidMod.MODID);

    public static final RegistryObject<Item> BANDAGE = ITEMS.register("bandage",
            () -> new BandageItem(new Item.Properties()
                    .group(ItemGroup.COMBAT)
                    .maxStackSize(16)));

    public static final RegistryObject<Item> FIELD_RATION = ITEMS.register("field_ration",
            () -> new Item(new Item.Properties()
                    .group(ItemGroup.FOOD)
                    .food(new Food.Builder().hunger(5).saturation(0.6F).build())
                    .maxStackSize(16)));

    public static final RegistryObject<Item> FIELD_HELMET = ITEMS.register("field_helmet",
            () -> new FieldArmorItem(ZomboidArmorMaterial.FIELD_GEAR, EquipmentSlotType.HEAD,
                    new Item.Properties().group(ItemGroup.COMBAT)));

    public static final RegistryObject<Item> FIELD_VEST = ITEMS.register("field_vest",
            () -> new FieldArmorItem(ZomboidArmorMaterial.FIELD_GEAR, EquipmentSlotType.CHEST,
                    new Item.Properties().group(ItemGroup.COMBAT)));

    public static final RegistryObject<Item> CARGO_PANTS = ITEMS.register("cargo_pants",
            () -> new FieldArmorItem(ZomboidArmorMaterial.FIELD_GEAR, EquipmentSlotType.LEGS,
                    new Item.Properties().group(ItemGroup.COMBAT)));

    public static final RegistryObject<Item> FIELD_BOOTS = ITEMS.register("field_boots",
            () -> new FieldArmorItem(ZomboidArmorMaterial.FIELD_GEAR, EquipmentSlotType.FEET,
                    new Item.Properties().group(ItemGroup.COMBAT)));

    private ModItems() {}
}
